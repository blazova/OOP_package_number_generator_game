from setuptools import setup

setup(name='oop_guessing_game',
      version='0.1',
      description='Simple modularized game between two players where one picks a number within a specific range and the other one guesses it',
      packages=['oop_guessing_game'],
      zip_safe=False)
